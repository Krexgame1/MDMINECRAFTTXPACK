```json
{
  "title": "Diluting Dragon's Breath",
  "icon": "minecraft:cauldron"
}
```
